// scripts.js
// JavaScript 코드
// 여기에는 제품 목록을 동적으로 로드하는 기능 등이 포함될 수 있습니다.
